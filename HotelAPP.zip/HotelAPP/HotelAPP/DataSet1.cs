﻿namespace HotelAPP
{
}
namespace HotelAPP {
    
    
    public partial class DataSet1 {
        partial class DataTable1DataTable
        {
        }
    }
}
